<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title>Actualités</title>
	<link rel="stylesheet" type="text/css" href="../StylePage/style.css">
</head>
<body>
	<?php require_once 'EnteteMenu.php'; ?>
	<div class="ContenuDivP">
		<?php if (!empty($articles)): ?>
			<?php foreach ($articles as $article): ?>
				<div>
					<h3 ><a href="index.php?action=article&id=<?= $article->id ?>"><?= $article->titre ?></a></h3>
					<p><?= substr($article->contenu, 0, 300) . '...' ?></p>
				</div>
			<?php endforeach ?>
		<?php else: ?>
			<div class="message">Aucun article trouvé !</div>
		<?php endif ?>
	</div>
</body>
</html>