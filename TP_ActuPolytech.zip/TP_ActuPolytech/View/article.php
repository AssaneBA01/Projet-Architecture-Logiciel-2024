<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title>Affichage d'un article</title>
	<link rel="stylesheet" type="text/css" href="../StylePage/style.css">
</head>
<body>
	<?php require_once 'EnteteMenu.php'; ?>

	<?php if (!empty($article)): ?>
		<div class="ContenuDivP">
			<h3><?= $article->titre ?></h3>
			<span >Publié le <?= $article->dateCreation ?></span>
			<p><?= $article->contenu ?></p>
		</div>
	<?php else: ?>
		<div >L'article demandé n'existe pas</div>
	<?php endif ?>
</body>
</html>