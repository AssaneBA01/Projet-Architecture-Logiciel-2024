<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Actu-ESP</title>
<link rel="stylesheet" href="../StylePage/style.css">

<?php
  require_once '../Controller/Controller.php';
  $categories = Categorie::getList();
?>

<div class="content">
  <div class="navbar">
      <div>
        <img src="../image/esp.png" alt="Logo ESP">
      </div>

      <div>
        <h2 class="TitreP">ACTUALITÉS POLYTECHNICIENNES</h2>
      </div>

        <ul>
          <?php foreach ($categories as $categorie): ?>
            <li><a href="index.php?action=categorie&id=<?= $categorie->id ?>"><?= $categorie->libelle ?></a></li>
          <?php endforeach ?>
        </ul>
    </div>
</div>

