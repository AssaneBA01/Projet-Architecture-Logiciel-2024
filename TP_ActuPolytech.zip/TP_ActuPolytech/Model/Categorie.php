<?php
	/**
	 * Représentation catégorie
	 */
	require_once '../Model/CnxDataBase.php';
	class Categorie{
		public $id;
		public $libelle;

		public static function getList(){
			$bdd = CnxDataBase::getInstance();
			$reponse = $bdd->query('SELECT * FROM categorie');
			$data = $reponse->fetchAll(PDO::FETCH_CLASS, 'categorie');
			$reponse->closeCursor();
			return $data;
		}

		public static function getById($id){
			$bdd = CnxDataBase::getInstance();
			$reponse = $bdd->query('SELECT * FROM categorie WHERE id = '.$id);
			$data = $reponse->fetch(PDO::FETCH_OBJ);
			$reponse->closeCursor();
			return $data;
		}
	}
?>