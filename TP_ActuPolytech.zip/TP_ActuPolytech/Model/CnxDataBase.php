<?php
	/**
	 * Connexions à la base de données
	 */
	class CnxDataBase{
		public static function getInstance(){
			$host = 'localhost';
			$dbname = 'actuesp';
			$user = 'root';
			$password = '';
			
			try{
				$bdd = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8", $user, $password);
			}
			catch (Exception $e){
				echo "Erreur de connexion à la base de données : ".$e->getMessage();
				$bdd = null;
			}
			return $bdd;
		}
	}
?>